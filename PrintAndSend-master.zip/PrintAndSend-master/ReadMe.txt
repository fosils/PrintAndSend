       Print and Send
   =======================

This project contain files and logic to build eBogholderen.dk PDF Printer.
 - Drivers		32bit & 64bit postscript based printer drivers
 - GS9.05_x32	32bit GhostScript v.9.05 binaries that is handling pdf building
 - PDFCreator	32bit & 64bit pdfforge PDFCreator monitor DLL's (not used anymore)
 - RedMon		32bit & 64bit RedMon redirector libraries v.1.9 with full sources
 - Resources	Some images used by app and installer
 - PrintManager	eBogholderen.dk file submitter app that is handling file creation and 
				uploading, and an installer helper library
									
Step by step compiling:
1. Using Delphi XE or later (recommended XE2) open delphi project groput: 
	PrintManager\Sources\PrintManager.groupproj
and build isxHelper and uplGUI project.
2. Using InnoSetup v. 5.5.x or later open Setup.iss and build the installer
3. Setup package will be created under Release folder.


Good luck,
Sorin Chitu [aka slimbyte]

	
	


	
	