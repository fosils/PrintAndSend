PrintAndSend
============
